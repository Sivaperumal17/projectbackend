import { fileURLToPath } from 'url';
import { dirname } from 'path';
import express from 'express';
import mysql from 'mysql';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import nodemailer from 'nodemailer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
// Initialize express app
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the 'uploads' directory
const uploadsPath = path.join(__dirname, 'uploads');
app.use('/uploads', express.static(uploadsPath));

app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:5174', 'http://localhost:3000'],
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Setup MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'bookings',
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL database:', err);
  } else {
    console.log('Connected to MySQL database');
  }
});
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // specify the directory where you want to save the files
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + "_" + Date.now() + path.extname(file.originalname)); // use the original file name for saving
  }
});

const upload = multer({ storage: storage });

app.post('/api/createpost', upload.single('image'), (req, res) => {
  const { title, content, author, date } = req.body;
  const image = req.file ? req.file.filename : null;

  const sql = 'INSERT INTO blog_posts (title, content, author, image, date) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [title, content, author, image, date], (err, result) => {
    if (err) {
      res.status(500).json({ message: 'Failed to create blog post', error: err });
      return;
    }
    res.status(201).json({ message: 'Blog post created successfully' });
  });
});

app.get('/api/posts', (req, res) => {
  const sql = 'SELECT * FROM blog_posts';
  db.query(sql, (err, result) => {
    if (err) {
      res.status(500).json({ message: 'Failed to fetch blog posts', error: err });
      return;
    }
    res.json(result);
  });
});


// Function to generate a random booking ID
const generateBookingID = () => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let bookingId = '';
  for (let i = 0; i < 8; i++) {
    bookingId += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return bookingId;
};

// Setup nodemailer transporter with your email credentials
const transporter = nodemailer.createTransport({
  service: 'Gmail',
  auth: {
    user: 'autmdu@autmdu.in', // Your email
    pass: 'jkginsybdisujiln'           // Your email password
  }
});

app.put('/api/bookings/accept/:id', (req, res) => {
  const bookingId = req.params.id;

  // Generate booking ID
  const generatedBookingID = generateBookingID();

  const updateSql = 'UPDATE bookings SET status = "accepted", booking_id = ? WHERE id = ?';

  connection.query(updateSql, [generatedBookingID, bookingId], (updateErr, updateResult) => {
    if (updateErr) {
      console.error('Error accepting booking:', updateErr);
      return res.status(500).send('Error accepting booking');
    }

    // Fetch booking details to get email details
    const fetchSql = 'SELECT * FROM bookings WHERE id = ?';
    connection.query(fetchSql, [bookingId], (fetchErr, fetchResults) => {
      if (fetchErr) {
        console.error('Error fetching booking details:', fetchErr);
        return res.status(500).send('Error fetching booking details');
      }

      if (fetchResults.length === 0) {
        return res.status(404).send('Booking not found');
      }

      const booking = fetchResults[0];

      const date = new Date(booking.date);
      const formattedDate = date.toISOString().split('T')[0]; // Format to 'yyyy-MM-dd

      // Send email with booking details
      const mailOptions = {
        from: 'autmdu@autmdu.in', // Sender address
        to: booking.email, // Receiver's email
        subject: 'Welcome to Janani Jothidam Maiyaam', // Subject line
        html: `
          <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #f9f9f9;">
            <h1 style="color: #A6ACAF;">Welcome to Janani Jothidam Maiyaam</h1>
            <p style="color: green;">Dear ${booking.name},</p>
            <p>Your booking is confirmed. Here are the details:</p>
            <ul>
            <li><strong>Purpose:</strong> ${booking.purpose}</li><br>
              <li><strong>Booking ID:</strong> ${generatedBookingID}</li><br>
              <li><strong>status:</strong> ${booking.status}</li><br>
                <li><strong>Date:</strong> ${formattedDate}</li><br>
              <li><strong>Slot:</strong> ${booking.slot}</li><br>
            </ul>
            <p>Thank you for choosing our service!</p>
            <p style="color: #4CAF50;">Best regards,</p>
            <p style="color: red;">Janani Jothidam Maiyaam</p>
            <p>For enquiries, contact: <strong>094446 63519, 097106 08609</strong></p><br>
            <center>
              <p style="color: #FFC300;">
                  <a href="https://www.aetherixdot.com/" style="color: inherit; text-decoration: none;">Developed by Aetherix.</a>
              </p>
          </center>
            <div style="background-color: brown; color: white; padding: 10px; margin-top: 20px;">
            <center><p style="text-decoration: underline;">Address:</p></center>
      <p>No 21, 73, Vellala St, Muthuamman Nagar, Thanthai Periyar Nagar, Ayanavaram, Chennai, Tamil Nadu 600023</p>
    </div>
          </div>
        `
      };

      transporter.sendMail(mailOptions, (mailErr, info) => {
        if (mailErr) {
          console.error('Error sending email:', mailErr);
          return res.status(500).send('Error sending email');
        } else {
          console.log('Email sent: ' + info.response);
          res.status(200).send('Booking accepted and email sent successfully');
        }
      });
    });
  });
});

// Route to handle GET requests to /api/slots for a specific date
app.get('/api/slots', (req, res) => {
  const date = req.query.date;
  if (!date) {
    return res.status(400).send('Date is required');
  }

  const sql = `
    SELECT s.time, IF(b.slot IS NOT NULL, true, false) AS is_booked
    FROM slots s
    LEFT JOIN bookings b ON s.time = b.slot AND b.date = ?
  `;

  connection.query(sql, [date], (err, results) => {
    if (err) {
      console.error('Error fetching slots from database:', err);
      res.status(500).send('Error fetching slots from database');
    } else {
      console.log('Slots fetched from database:', results);
      res.json(results);
    }
  });
});

// Route to handle PUT requests to /api/bookings/generate-id/:id
app.put('/api/bookings/generate-id/:id', (req, res) => {
  const bookingId = req.params.id;
  const generatedBookingID = generateBookingID(); // Generate booking ID

  const sql = 'UPDATE bookings SET booking_id = ? WHERE id = ?';

  connection.query(sql, [generatedBookingID, bookingId], (err, result) => {
    if (err) {
      console.error('Error generating booking ID:', err);
      res.status(500).send('Error generating booking ID');
    } else {
      console.log('Booking ID generated successfully:', generatedBookingID);
      res.status(200).send('Booking ID generated successfully');
    }
  });
});

// Define your generateTempId function
function generateTempId() {
  const characters = '0123456789';
  let tempId = '';
  for (let i = 0; i < 8; i++) {
    tempId += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return tempId;
}

// Route to handle POST requests to /api/bookings
app.post('/api/bookings', (req, res) => {
  const { name, whatsappNumber, email, address, purpose, date, slot } = req.body;

  // Generate temporary ID
  const tempId = generateTempId(); // Assuming this function generates the temporary ID

  const sql = 'INSERT INTO bookings (name, whatsapp_number, email, address, purpose, date, slot, status, temp_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
  connection.query(sql, [name, whatsappNumber, email, address, purpose, date, slot, 'pending', tempId], (err, result) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        res.status(400).send('This slot is already booked for the selected date');
      } else {
        console.error('Error inserting data into database:', err);
        res.status(500).send('Error inserting data into database');
      }
    } else {
      console.log('Data inserted into database');
      // Send the temporary ID in the response
      res.status(200).send({ message: 'Your Status ID:', tempId: tempId });
    }
  });
});



// Route to handle GET requests to /api/bookings
app.get('/api/bookings', (req, res) => {
  const sql = 'SELECT * FROM bookings';

  connection.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching bookings from database:', err);
      res.status(500).send('Error fetching bookings from database');
    } else {
      res.json(results);
    }
  });
});

// Route to handle DELETE requests to /api/bookings/reject/:id
app.delete('/api/bookings/reject/:id', (req, res) => {
  const bookingId = req.params.id;
  const sql = 'UPDATE bookings SET status = "rejected", booking_id = NULL, date = NULL, slot = NULL WHERE id = ?';

  connection.query(sql, [bookingId], (err, result) => {
    if (err) {
      console.error('Error rejecting booking:', err);
      res.status(500).send('Error rejecting booking');
    } else {
      res.status(200).send('Booking rejected');
    }
  });
});

// Route to handle PUT requests to /api/bookings/edit/:id
app.put('/api/bookings/edit/:id', (req, res) => {
  const bookingId = req.params.id;
  const { newDate, newSlot } = req.body;

  // Query to fetch existing bookings for the selected date
  const bookingsQuery = 'SELECT slot FROM bookings WHERE date = ?';

  connection.query(bookingsQuery, [newDate], (err, rows) => {
    if (err) {
      console.error('Error fetching existing bookings:', err);
      res.status(500).send('Error fetching existing bookings');
    } else {
      // Extract booked slots from the rows
      const bookedSlots = rows.map(row => row.slot);

      // Define the available slots for the selected date
      const availableSlots = [
        '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM',
        '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM',
        '4:00 PM', '4:30 PM', '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM',
        '7:00 PM', '7:30 PM', '8:00 PM'
      ];

      // Filter out the booked slots from the available slots
      const availableSlotsFiltered = availableSlots.filter(slot => !bookedSlots.includes(slot));

      // If the new slot is available, update the booking
      if (!bookedSlots.includes(newSlot)) {
        const updateBookingQuery = 'UPDATE bookings SET date = ?, slot = ? WHERE id = ?';
        connection.query(updateBookingQuery, [newDate, newSlot, bookingId], (updateErr, updateResult) => {
          if (updateErr) {
            console.error('Error updating booking:', updateErr);
            res.status(500).send('Error updating booking');
          } else {
            res.status(200).send('Booking updated successfully');
          }
        });
      } else {
        res.status(400).send('This slot is already booked for the selected date');
      }
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});